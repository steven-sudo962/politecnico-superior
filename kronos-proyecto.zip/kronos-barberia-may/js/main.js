// KRONOS - Lógica de interacción (menú móvil, scroll, filtros, modal de reservas)
// Mobile menu toggle
const menuBtn = document.getElementById('menu-btn');
const mobileMenu = document.getElementById('mobile-menu');

menuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
});

// Navbar scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('shadow-xl', 'bg-black/95');
    } else {
        navbar.classList.remove('shadow-xl', 'bg-black/95');
    }
});

// Filter Services Function
function filterServices(category) {
    const cards = document.querySelectorAll('.service-card');
    const buttons = document.querySelectorAll('.service-filter-btn');

    buttons.forEach(btn => {
        btn.classList.remove('bg-gold-500', 'text-black', 'shadow-md');
        btn.classList.add('bg-carddark', 'text-neutral-400', 'border', 'border-neutral-800');
    });

    const activeBtn = document.getElementById(`btn-${category}`);
    if (activeBtn) {
        activeBtn.classList.remove('bg-carddark', 'text-neutral-400', 'border', 'border-neutral-800');
        activeBtn.classList.add('bg-gold-500', 'text-black', 'shadow-md');
    }

    cards.forEach(card => {
        if (category === 'all' || card.getAttribute('data-category') === category) {
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
}

// Modal Functions
function openBookingModal(serviceName = '', price = '') {
    const modal = document.getElementById('booking-modal');
    modal.classList.remove('hidden');
    if (serviceName) {
        const select = document.getElementById('modal-service');
        for (let i = 0; i < select.options.length; i++) {
            if (select.options[i].text.includes(serviceName.split(' ')[0])) {
                select.selectedIndex = i;
                break;
            }
        }
    }
}

function closeBookingModal() {
    const modal = document.getElementById('booking-modal');
    modal.classList.add('hidden');
}

// Booking form handler with custom notification box (No alert used)
function handleBookingSubmit(event) {
    event.preventDefault();
    closeBookingModal();
    
    const notification = document.getElementById('notification-box');
    notification.classList.remove('translate-y-32', 'opacity-0');
    
    setTimeout(() => {
        notification.classList.add('translate-y-32', 'opacity-0');
    }, 4000);
}
