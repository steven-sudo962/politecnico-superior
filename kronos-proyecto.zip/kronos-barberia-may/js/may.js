// ------------------------------------------------------------------
// May: asistente virtual con voz (frontend)
// ------------------------------------------------------------------
// NOTA IMPORTANTE: aquí NO va la API key de Gemini. Este bloque solo
// llama a MAY_BACKEND_URL (tu futuro servidor), que es quien debe
// guardar la API key y hablar con Gemini/Ollama. Mientras ese
// servidor no exista, se muestran respuestas de ejemplo (modo demo).
const MAY_BACKEND_URL = '/api/may'; // cámbialo cuando tengas el servidor
const MAY_DEMO_MODE = true; // ponlo en false cuando el backend exista

const mayPanel = document.getElementById('may-panel');
const mayMessages = document.getElementById('may-messages');
const mayForm = document.getElementById('may-form');
const mayInput = document.getElementById('may-input');
const mayMicBtn = document.getElementById('may-mic-btn');
const mayStatus = document.getElementById('may-status');

let mayGreeted = false;

function toggleMayPanel() {
    mayPanel.classList.toggle('hidden');
    if (!mayPanel.classList.contains('hidden') && !mayGreeted) {
        mayGreeted = true;
        addMayMessage('ai', '¡Hola! Soy May, la asistente virtual de KRONOS. Puedo darte información sobre servicios, horarios o ayudarte a agendar una cita. Escríbeme o pulsa el micrófono.');
        speakAsMay('¡Hola! Soy May, la asistente virtual de KRONOS. ¿En qué puedo ayudarte?');
    }
}

function addMayMessage(sender, text) {
    const bubble = document.createElement('div');
    bubble.className = `may-bubble ${sender === 'user' ? 'may-bubble-user' : 'may-bubble-ai'}`;
    bubble.textContent = text;
    mayMessages.appendChild(bubble);
    mayMessages.scrollTop = mayMessages.scrollHeight;
}

mayForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const text = mayInput.value.trim();
    if (!text) return;
    mayInput.value = '';
    handleUserMessage(text);
});

async function handleUserMessage(text) {
    addMayMessage('user', text);
    mayStatus.textContent = 'Escribiendo...';

    const reply = await askMay(text);

    mayStatus.textContent = 'Asistente de KRONOS';
    addMayMessage('ai', reply);
    speakAsMay(reply);
}

async function askMay(text) {
    if (MAY_DEMO_MODE) {
        return getDemoReply(text);
    }
    try {
        const response = await fetch(MAY_BACKEND_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: text }),
        });
        if (!response.ok) throw new Error('Respuesta no válida del servidor');
        const data = await response.json();
        return data.reply || 'No obtuve una respuesta clara, ¿puede repetirlo?';
    } catch (err) {
        console.error('Error consultando a May:', err);
        return 'No logro conectarme a mi servidor en este momento. Inténtelo de nuevo en un momento.';
    }
}

// Respuestas de ejemplo mientras no exista el backend real.
function getDemoReply(text) {
    const lower = text.toLowerCase();
    if (lower.includes('horario')) {
        return 'Atendemos de lunes a viernes de 9:00 a.m. a 8:00 p.m., y sábados de 10:00 a.m. a 7:00 p.m. Los domingos permanecemos cerrados.';
    }
    if (lower.includes('precio') || lower.includes('costo') || lower.includes('cuánto')) {
        return 'Nuestros servicios varían según el tipo de corte o tratamiento. Puede ver el detalle completo en la sección de Servicios, o decirme cuál le interesa.';
    }
    if (lower.includes('cita') || lower.includes('reserva') || lower.includes('agendar')) {
        return 'Con gusto. Puede usar el botón "Reservar Cita" en la parte superior, o decirme qué día y servicio prefiere y lo anoto por usted.';
    }
    if (lower.includes('ubicaci') || lower.includes('dirección') || lower.includes('dónde')) {
        return 'Estamos en la Av. Diagonal de los Caballeros #452, Distrito Financiero. ¿Le gustaría que le comparta el enlace de ubicación?';
    }
    return `(Modo demo, sin servidor conectado) Recibí: "${text}". Cuando conectemos el backend con Gemini, responderé con inteligencia real.`;
}

// --- Reconocimiento de voz (Speech-to-Text nativo del navegador) ---
const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let listening = false;

if (SpeechRecognitionAPI) {
    recognition = new SpeechRecognitionAPI();
    recognition.lang = 'es-CO';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
        listening = true;
        mayMicBtn.classList.add('listening');
        mayStatus.textContent = 'Escuchando...';
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        handleUserMessage(transcript);
    };

    recognition.onerror = (event) => {
        console.error('Error de reconocimiento de voz:', event.error);
        mayStatus.textContent = 'No pude escuchar bien, intente de nuevo.';
    };

    recognition.onend = () => {
        listening = false;
        mayMicBtn.classList.remove('listening');
        if (mayStatus.textContent === 'Escuchando...') {
            mayStatus.textContent = 'Asistente de KRONOS';
        }
    };
} else {
    mayMicBtn.disabled = true;
    mayMicBtn.title = 'Tu navegador no soporta reconocimiento de voz';
}

function toggleMicListening() {
    if (!recognition || listening) return;
    try {
        recognition.start();
    } catch (err) {
        console.error('No se pudo iniciar el micrófono:', err);
    }
}

// --- Síntesis de voz (Text-to-Speech nativo del navegador) ---
let cachedVoices = [];

function loadVoices() {
    cachedVoices = window.speechSynthesis.getVoices();
}
loadVoices();
if ('speechSynthesis' in window) {
    window.speechSynthesis.onvoiceschanged = loadVoices;
}

// Nombres de voces femeninas en español que suelen venir instaladas
// en Windows (Microsoft) y Chrome/Google. Si tu sistema tiene otra,
// agrégala aquí.
const FEMALE_VOICE_HINTS = [
    'google español', 'sabina', 'helena', 'paulina', 'mónica', 'monica',
    'lucia', 'lucía', 'elvira', 'esperanza', 'female', 'mujer', 'femenina'
];

function pickFemaleSpanishVoice() {
    const spanishVoices = cachedVoices.filter(v => v.lang.toLowerCase().startsWith('es'));
    if (spanishVoices.length === 0) return null;

    const byHint = spanishVoices.find(v =>
        FEMALE_VOICE_HINTS.some(hint => v.name.toLowerCase().includes(hint))
    );
    if (byHint) return byHint;

    // Si no hay coincidencia por nombre, al menos evita nombres
    // típicamente masculinos conocidos.
    const MALE_VOICE_HINTS = ['jorge', 'diego', 'raul', 'raúl', 'pablo', 'male', 'hombre'];
    const notMale = spanishVoices.find(v =>
        !MALE_VOICE_HINTS.some(hint => v.name.toLowerCase().includes(hint))
    );
    return notMale || spanishVoices[0];
}

function speakAsMay(text) {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel(); // evita solapar frases anteriores

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'es-CO';
    utterance.rate = 1;
    utterance.pitch = 1.1; // tono ligeramente más agudo, refuerza el timbre femenino

    const spanishVoice = pickFemaleSpanishVoice();
    if (spanishVoice) utterance.voice = spanishVoice;

    window.speechSynthesis.speak(utterance);
}
